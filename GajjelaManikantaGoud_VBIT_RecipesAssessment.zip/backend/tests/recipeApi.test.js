
const request = require('supertest');
const app = require('../server'); // assume server exports Express app

describe('Recipe API Endpoints', () => {
  it('should fetch paginated recipes', async () => {
    const res = await request(app).get('/api/recipes?page=1&limit=2');
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('data');
  });

  it('should filter recipes by cuisine', async () => {
    const res = await request(app).get('/api/recipes/filter?cuisine=Italian');
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('data');
  });
});
