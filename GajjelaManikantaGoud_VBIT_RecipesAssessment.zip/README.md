
# Securin Recipe App – Dockerized

## Quick Start
1. Clone or unzip project.
2. Run `docker-compose up --build`.
3. Access:
   - Backend: http://localhost:5000/api/recipes
   - Frontend: http://localhost:3000
4. Import `Securin_Recipe_API.postman_collection.json` into Postman.

## Testing
- Run backend tests:
```bash
cd backend
npm install
npm test
```
